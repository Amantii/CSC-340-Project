import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Main {
    public static void main(String[] args) throws SQLException {

        // establish DB url
//        String myDriverClass = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/hospital_DB";
        String user = "root";
        String password = "password";

        Connection myConn = null;
        Statement myStmt = null;
        ResultSet rs = null;

        try {
            myConn = DriverManager.getConnection(url, user, password);
            myStmt = myConn.createStatement();
            String sql = "Select * from hospital_DB.appointment";
            rs = myStmt.executeQuery(sql);
//            INSERT INTO `appointments` (`id`,`user_id`,`title`,`date`, `start`,`end`,`note`)
//            VALUES('28222', 'chri8472f', 'Radiation','2020-12-27', '12:45:00', '11:15:00', 'gghs adj hhdj');

            while (rs.next()) {
                System.out.println(rs.getString("doc_id") + "\t\t " + rs.getString("pat_id") + "\t\t " + rs.getString("appointment_id") + "\t\t "+ rs.getDate("date") + "\t\t" + rs.getTime("time") + "\t\t" + rs.getString("notes"));
            }

        } catch (SQLException e) {
            System.out.println("Error connecting to DB: " + e.getMessage());
        }
        catch (Exception exc) {
            exc.printStackTrace();
        }
        finally {
            if (rs != null) {
                rs.close();
            }

            if (myStmt != null) {
                myStmt.close();
            }

            if (myConn != null) {
                myConn.close();
            }
        }
    }

}